import { PONTOS } from './pontos.js';

const WP = 'https://pt.wikipedia.org';
const cache = new Map(); // guarda as promessas, então cada consulta roda uma vez só

async function json(url) {
  const r = await fetch(url);
  if (!r.ok) throw new Error(r.status);
  return r.json();
}

function uma(chave, fn) {
  if (!cache.has(chave)) cache.set(chave, fn());
  return cache.get(chave);
}

// Filtros: tudo resolvido aqui, a interface só recebe a lista pronta.
export function getPontos({ q = '', cidade = '', tipo = '' } = {}) {
  const t = q.trim().toLowerCase();
  return PONTOS.filter((p) =>
    (!cidade || p.cidade === cidade) &&
    (!tipo || p.tipo === tipo) &&
    (!t || `${p.nome} ${p.cidade} ${p.resumo}`.toLowerCase().includes(t))
  );
}

export function getFiltros() {
  const unicos = (campo) => [...new Set(PONTOS.map((p) => p[campo]))].sort();
  return { cidades: unicos('cidade'), tipos: unicos('tipo') };
}

// Fonte 1: texto e coordenadas (API REST da Wikipédia)
export function getDetalhes(p) {
  return uma('d' + p.id, () =>
    json(`${WP}/api/rest_v1/page/summary/${encodeURIComponent(p.titulo)}`)
      .then((d) => ({ texto: d.extract, lat: d.coordinates?.lat, lon: d.coordinates?.lon, url: d.content_urls?.desktop?.page }))
      .catch(() => ({ texto: p.resumo }))
  );
}

// Fonte 2: imagem (API de ação da Wikipédia, pageimages)
export function getImagem(p) {
  return uma('i' + p.id, () =>
    json(`${WP}/w/api.php?action=query&format=json&origin=*&prop=pageimages&piprop=thumbnail&pithumbsize=1000&titles=${encodeURIComponent(p.titulo)}`)
      .then((d) => Object.values(d.query.pages)[0].thumbnail?.source ?? null)
      .catch(() => null)
  );
}
