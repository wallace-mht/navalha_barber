// Lista curada. "titulo" é o título do artigo na Wikipédia (pt) usado pelas APIs.
// "resumo" é o texto local, usado enquanto a API carrega ou se ela falhar.
export const DESTAQUE = 'serra-capivara';

export const PONTOS = [
  { id: 'serra-capivara', nome: 'Serra da Capivara', titulo: 'Parque Nacional da Serra da Capivara', cidade: 'São Raimundo Nonato', tipo: 'História', resumo: 'Um dos sítios arqueológicos mais importantes das Américas, com milhares de pinturas rupestres.' },
  { id: 'sete-cidades', nome: 'Sete Cidades', titulo: 'Parque Nacional de Sete Cidades', cidade: 'Piracuruca', tipo: 'Natureza', resumo: 'Formações rochosas esculpidas pelo tempo, trilhas e inscrições rupestres.' },
  { id: 'delta', nome: 'Delta do Parnaíba', titulo: 'Delta do Parnaíba', cidade: 'Parnaíba', tipo: 'Aventura', resumo: 'Delta em mar aberto, com ilhas, dunas e passeios de barco ao entardecer.' },
  { id: 'confusoes', nome: 'Serra das Confusões', titulo: 'Parque Nacional da Serra das Confusões', cidade: 'Caracol', tipo: 'Natureza', resumo: 'Cânions, cavernas e a maior área de caatinga preservada do país.' },
  { id: 'oeiras', nome: 'Oeiras', titulo: 'Oeiras (Piauí)', cidade: 'Oeiras', tipo: 'Cultura', resumo: 'Primeira capital do Piauí, com casario colonial e forte tradição religiosa.' },
  { id: 'teresina', nome: 'Teresina e o Encontro dos Rios', titulo: 'Teresina', cidade: 'Teresina', tipo: 'Cultura', resumo: 'Capital às margens dos rios Poti e Parnaíba, com cerâmica artesanal e culinária marcante.' },
];
