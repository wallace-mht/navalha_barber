// Conteúdo do site. Para ligar um documento, preencha "href" (ex.: 'materiais/pop.pdf' ou link do Trello/Planner).
export const KIT = [
  { id: 'fluxo', titulo: 'Fluxo de atendimento', desc: 'Etapas e responsabilidades, do primeiro contato à conclusão da solicitação.', acao: 'Visualizar fluxo de atendimento', href: '' },
  { id: 'pop', titulo: 'POP', desc: 'Procedimento Operacional Padrão: como executar cada etapa do atendimento.', acao: 'Consultar POP', href: '' },
  { id: 'protocolo', titulo: 'Protocolo de comunicação', desc: 'Como responder dúvidas, tratar reclamações e encaminhar demandas.', acao: 'Consultar protocolo de comunicação', href: '' },
  { id: 'painel', titulo: 'Painel de acompanhamento', desc: 'Registro e acompanhamento das solicitações no Trello ou Microsoft Planner.', acao: 'Acessar painel de solicitações', href: '' },
  { id: 'manual', titulo: 'Manual de utilização', desc: 'Orientações para usar corretamente todos os componentes do kit.', acao: 'Abrir manual de utilização', href: '' },
];

export const PASSOS = [
  'Consulte o fluxo para compreender as etapas.',
  'Siga o POP durante o atendimento.',
  'Utilize o protocolo para responder e encaminhar demandas.',
  'Registre e acompanhe as solicitações no painel.',
  'Consulte o manual quando precisar de ajuda.',
];

export const CONTATO = {
  empresa: 'FLY Serviços Turísticos',
  endereco: 'Av. Dep. Pinheiro Machado, 359, Reis Veloso, Parnaíba - PI',
  telefone: '(86) 99421-2065',
  whatsapp: 'https://wa.me/5586994212065',
  instagram: 'https://instagram.com/fly.phb',
  responsavel: 'Responsável pelo kit: a definir pela empresa',
};
