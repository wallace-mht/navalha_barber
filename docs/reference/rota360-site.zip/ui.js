import { KIT, PASSOS, CONTATO } from './kit.js';
import { PONTOS } from './pontos.js';
import { getImagem } from './api.js';

const $ = (s) => document.querySelector(s);

$('#kit-cards').innerHTML = KIT.map((k, i) => `
  <article class="rounded-3xl bg-offwhite p-6">
    <span class="flex h-10 w-10 items-center justify-center rounded-full bg-floresta text-offwhite">${i + 1}</span>
    <h3 class="mt-4 text-xl font-medium">${k.titulo}</h3>
    <p class="mt-2 text-grafite/70">${k.desc}</p>
  </article>`).join('');

// Botão ativo se o documento existir; senão, aviso "em breve".
$('#materiais-lista').innerHTML = KIT.map((k) => {
  const ok = !!k.href;
  const ext = /^https?:|\.pdf$/.test(k.href) ? 'target="_blank" rel="noopener"' : '';
  return `<div class="flex flex-wrap items-center justify-between gap-4 rounded-2xl border border-grafite/15 bg-offwhite p-5">
    <div><h3 class="text-lg font-medium">${k.titulo}</h3><p class="text-sm text-grafite/60">${ok ? 'Disponível' : 'Documento em breve'}</p></div>
    ${ok ? `<a href="${k.href}" ${ext} class="rounded-full bg-floresta px-6 py-3 text-offwhite hover:bg-floresta/90">${k.acao}</a>`
         : `<span aria-disabled="true" class="rounded-full bg-bege px-6 py-3 text-grafite/50">${k.acao}</span>`}
  </div>`;
}).join('');

$('#passos').innerHTML = PASSOS.map((t, i) => `
  <li class="flex gap-4 rounded-2xl bg-offwhite p-5"><span class="text-3xl font-light text-caramelo">${i + 1}</span><p class="self-center">${t}</p></li>`).join('');

$('#destinos').innerHTML = ['delta', 'serra-capivara', 'sete-cidades'].map((id) => {
  const p = PONTOS.find((x) => x.id === id);
  return `<figure><div data-foto="${id}" class="h-44 rounded-2xl bg-cover bg-center" style="background-image:linear-gradient(135deg,#1F3D32,#C49A6C)"></div>
    <figcaption class="mt-2 text-sm">${p.nome}<span class="text-grafite/60"> · ${p.cidade}</span></figcaption></figure>`;
}).join('');
document.querySelectorAll('[data-foto]').forEach((el) => {
  getImagem(PONTOS.find((x) => x.id === el.dataset.foto)).then((src) => { if (src) el.style.backgroundImage = `url("${src}")`; });
});

$('#contato-info').innerHTML = `
  <p class="text-lg font-medium">${CONTATO.empresa}</p>
  <p class="mt-1 text-offwhite/80">${CONTATO.endereco}</p>
  <p class="mt-1 text-offwhite/80">${CONTATO.responsavel}</p>
  <div class="mt-6 flex flex-wrap gap-3">
    <a href="${CONTATO.whatsapp}" target="_blank" rel="noopener" class="rounded-full bg-caramelo px-6 py-3 font-medium text-floresta">WhatsApp ${CONTATO.telefone}</a>
    <a href="${CONTATO.instagram}" target="_blank" rel="noopener" class="rounded-full border border-offwhite/40 px-6 py-3">Instagram @fly.phb</a>
  </div>`;
